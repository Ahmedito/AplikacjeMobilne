package com.example.lab02;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Toast;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Panel P;
    Paint tlo1 = new Paint();
    Paint tlo2 = new Paint();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(P = new Panel(this));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.creator) {
            Context context = getApplicationContext();
            CharSequence text = "Twórca Bartosz Wojciechowski";
            int czas = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, czas);
            toast.setGravity(Gravity.BOTTOM | Gravity.BOTTOM, 0, 0);
            toast.show();
            return true;
        } else if (itemId == R.id.exit) {
            finish();
            return true;
        } else if (itemId == R.id.color1) {
            tlo1.setColor(Color.BLACK);
            tlo2.setColor(Color.WHITE);
            P.postInvalidate();
            return true;
        } else if (itemId == R.id.color2) {
            tlo1.setColor(Color.RED);
            tlo2.setColor(Color.YELLOW);
            P.postInvalidate();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    class Panel extends View {
        private boolean isFlipped = false;

        public Panel(Context context) {
            super(context);
            tlo1.setColor(Color.WHITE);
            tlo2.setColor(Color.BLACK);
        }

        public void setFlipped(boolean flipped) {
            isFlipped = flipped;
            postInvalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.GRAY);
            int width = getWidth();
            int height = getHeight();
            int smallerDimension = Math.min(width, height);
            float squareSize = smallerDimension / 8;

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    int x, y;
                    if (isFlipped) {
                        x = 7 - i;
                        y = j;
                    } else {
                        x = i;
                        y = j;
                    }

                    if ((x + y) % 2 == 0) {
                        canvas.drawRect(x * squareSize, y * squareSize, (x + 1) * squareSize, (y + 1) * squareSize, tlo1);
                    } else {
                        canvas.drawRect(x * squareSize, y * squareSize, (x + 1) * squareSize, (y + 1) * squareSize, tlo2);
                    }
                }
            }
        }
    }
}
