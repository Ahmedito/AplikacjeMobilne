package com.example.jsonzad;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String jsonString = "{\"info\":{\"przedmiot\":\"Aplikacje mobilne\",\"prowadzacy\":\"Marek Genge\",\"szkola\":\"Zespol Szkol Elektrycznych\",\"miasto\":\"Gorzow Wielkopolski\",\"dataczas\":\"2023-11-22 22:43\"},\"18\":\"Wojciechowski Bartosz\"}";

        TextView textView = findViewById(R.id.textView);
        textView.setText(jsonString);
    }
}
