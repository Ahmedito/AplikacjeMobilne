package com.example.jsonzad;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            String jsonString = "{\"info\":{\"przedmiot\":\"Aplikacje mobilne\",\"prowadzacy\":\"Marek Genge\",\"szkola\":\"Zespol Szkol Elektrycznych\",\"miasto\":\"Gorzow Wielkopolski\",\"dataczas\":\"2023-11-22 22:43\"},\"numer\":\"18\",\"imie\":\"Wojciechowski Bartosz\"}";

            JSONObject json = new JSONObject(jsonString);

            JSONObject infoObj = json.getJSONObject("info");
            String przedmiot = infoObj.getString("przedmiot");
            String prowadzacy = infoObj.getString("prowadzacy");
            String szkola = infoObj.getString("szkola");
            String miasto = infoObj.getString("miasto");
            String dataczas = infoObj.getString("dataczas");
            String numer = json.getString("numer");
            String imie = json.getString("imie");

            TextView textView = findViewById(R.id.textView);
            textView.setText("Przedmiot: " + przedmiot + "\nProwadzacy: " + prowadzacy + "\nszkola: " + szkola + "\nmiasto: " + miasto + "\ndataczas: " + dataczas + "\nnumer: " + numer + "\nimie: " + imie);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
