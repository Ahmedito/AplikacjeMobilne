package com.example.odliczaniedonowegoroku;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

        private TextView countdownTextView;
        private TextView currentDateTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                countdownTextView = findViewById(R.id.countdownTextView);
                currentDateTextView = findViewById(R.id.currentDateTextView);


                Calendar endOfYear = Calendar.getInstance();
                endOfYear.set(Calendar.MONTH, Calendar.DECEMBER);
                endOfYear.set(Calendar.DAY_OF_MONTH, 31);
                endOfYear.set(Calendar.HOUR_OF_DAY, 23);
                endOfYear.set(Calendar.MINUTE, 59);
                endOfYear.set(Calendar.SECOND, 59);


                startCountdown(endOfYear);
                updateCurrentDateTime();
                startRealTimeUpdater();
        }

        private void startCountdown(Calendar endDate) {
                Handler handler = new Handler();

                Timer timer = new Timer();

                TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                                Calendar currentTime = Calendar.getInstance();
                                long differenceInMillis = endDate.getTimeInMillis() - currentTime.getTimeInMillis();

                                long days = differenceInMillis / (1000 * 60 * 60 * 24);
                                long hours = (differenceInMillis % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
                                long minutes = (differenceInMillis % (1000 * 60 * 60)) / (1000 * 60);
                                long seconds = (differenceInMillis % (1000 * 60)) / 1000;

                                String countdownText = String.format(
                                        "%02d days %02d:%02d:%02d",
                                        days, hours, minutes, seconds
                                );

                                runOnUiThread(() -> countdownTextView.setText(countdownText));
                        }
                };

                timer.schedule(timerTask, 0, 1000);
        }

        private void updateCurrentDateTime() {
                Timer timer = new Timer();

                TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                                ZoneId warsawZone = ZoneId.of("Europe/Warsaw");
                                LocalDateTime currentTime = LocalDateTime.now(warsawZone);
                                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

                                String formattedDate = currentTime.format(formatter);

                                runOnUiThread(() -> currentDateTextView.setText("Dzisiejsza data " + formattedDate));
                        }
                };

                timer.schedule(timerTask, 0, 1000);
        }

        private void startRealTimeUpdater() {
                Timer timer = new Timer();

                TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                                runOnUiThread(() -> updateCurrentDateTime());
                        }
                };

                timer.schedule(timerTask, 0, 60000);
        }
}
